﻿public enum FruitType
{
    Watermelon,
    Muskmelon,
    DarkMelon
}
